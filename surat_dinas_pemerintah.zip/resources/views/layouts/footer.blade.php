<footer class="main-footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <p>&copy; OTOKABE | Developed By <a href="#" class="external">OTOKABE DEVELOPMENT</a></p>
            </div>
        </div>
    </div>
</footer>